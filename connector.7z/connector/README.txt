- T�l�charger et Installer xampp
- Lancer Xampp et d�marrer les serveurs MySQL et Apache
- Charger le repertoire connector dans htdocs
- Ouvrir le navigateur � la page : http://localhost/phpmyadmin
- Cr�er une base de donn�es et la nommer "kwazer"
- Charger le script de donn�es kwazer.sql


- ouvrir le projet sur la page : http://localhost/xampp/connector 

Project demo allowed to simulate with one product add to cart and payed