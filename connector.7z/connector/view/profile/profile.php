
<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');


?>

<div>
    <?php 
        session_start();

        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);

        $_SESSION["session"]= $userid;
        $username = $_SESSION["session"];
	
		
		$db = Util::getDb();
        $profile = Controller::findOne($db->getDbserver(), 'profile', 'userid', $userid);
		
		$user = Controller::findOne($db->getDbserver(), 'user', 'username', $userid);
		
       // print_r($profile);
    ?>

    <div id="profile">
	   <h1><?php echo  $profile['fullname'] ?></h1>
	   <div class="title"><?php echo $username ?></div>
	   <p>Réside dans la ville de : <?php echo $profile['city'] ?>, <?php echo $profile['country'] ?></p>
	   <h2>Contact information</h2>
		<ul>
			<li>Adresse : <?php echo $profile['location'] ?></li>
			<li>Tel: <?php echo $profile['phone'] ?></li>
		</ul>
	</div>
	<hr>
	<a href=<?php echo "settings.php?user=$username" ?>>Edit</a>
</div>