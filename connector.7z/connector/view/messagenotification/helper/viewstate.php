<?php 

    require('../../../appcore/config/dbconfig.php');
    require('../../../appcore/controller/controller.php');
    require('../../../src/util/util.php');


    $request_uri = $_SERVER['REQUEST_URI']; 
    $userid = substr(strstr($request_uri, '?'), 6);
	$id = substr(strstr($request_uri, '&'), 4);
	echo $id;
	$db = Util::getDb();
	$message = Controller::findOne($db->getDbserver(), 'messagenotification', 'mnid', $id);
	print_r($message);
	$message[4] = 1;
	$mnid = $message[0];
	Controller::update($db, 'messagenotification', 'mnid', $mnid, $message);
	$payedid = $message[2]; 
	$u = 'sportstore';
    $uri = 'Location: http://localhost/xampp/connector/view/comandpayed/order.php?user=';
    $url = "$uri$u&id=$payedid";
    header($url);
    exit;


    
?>