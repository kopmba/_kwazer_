



<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/category.php');
    
?>



<div id="container" class="container">
	 
	 <?php 
    
        session_start();
		$request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"];

        $db = Util::getDb();
        $user = Controller::findOne($db->getDbserver(), 'profile_producer', 'username', 'sportstore');
        //print_r($user);
        

        $order = Controller::findOne($db->getDbserver(), 'commandpayed', 'cpid', $id);
		$shipping = Controller::findOne($db->getDbserver(), 'shipping', 'cmdpayedid', $id);
		//print_r($shipping);
		$shipper = Controller::findOne($db->getDbserver(), 'profile', 'proid', $shipping['transporterid']);
		$shippers = Controller::find($db, 'shipper_list')
		//print_r($order);
		
     ?>
		<h1>Shipping</h1>
	<div>
        <p><h3>The command ref : </h3> <?php echo $order[1]; ?> &nbsp;&nbsp; 
        
    </div>
		
      
      <hr>
      
	  <article class="bounceInUp animated">
        <?php if($user['roleid'] == 3): ?>
			<section class="seven ninths padded">
			  <h3>Order Information</h3>
			  <div class="one whole two-up-small-tablet one-up-mobile">
				  <ol class="list">
					<li><?php echo $order['totalamount'] ?> #ETAT</li>
					<?php if($shipping[2] == 0): ?>
					  <li>Not denined: #Transporter</li>
					<?php endif ?>
					<?php if($shipping[2] == 1): ?>
					  <li><?php echo $shipper['fullname'] ?></li>
					<?php endif ?>
					<li>4 days #Process</li>
				  </ol>
			  </div>
			</section>
		<?php endif ?>
		
		<?php if($user['roleid'] == 1): ?>
			<section class="seven ninths padded">
			  <h3>Product Information</h3>
			  <div class="one whole two-up-small-tablet one-up-mobile">
				  <ol class="list">
					<li><?php echo $order['totalamount'] ?> #ETAT</li>
					<?php if($shipping[2] == 0): ?>
					  <li>Not defined: #Transporter</li>
					<?php endif ?>
					<?php if($shipping[1] == 1): ?>
					  <li><?php echo $shipper['fullname'] ?></li>
					<?php endif ?>
					<li>4 days #Process</li>
				  </ol>
			  </div>
			  
			  <form method="post" action=<?php echo "helper/ship.php?user=$username" ?>>
				  <p>
					<input type="text" name="id" hidden value=<?php echo $id ?>>
					<select name="shipper">
						<option>Shipper</option>
						<?php foreach ($shippers as $key => $value): ?>
							<option value=<?php echo $value[0] ?>><?php echo $value[1] ?></option>
						<?php endforeach ?>
					</select>
					<br><br>
					<input type="submit" class="asphalt" value="Order Shipping">
				  </p>
			  </form>
			</section>
		<?php endif ?>
		
		
      </article>
       
	  
</div>