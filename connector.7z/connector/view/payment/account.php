<?php 

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/payment.php');
    
?>

<div>
    <?php 
        session_start();
         $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		$id = substr(strstr($request_uri, '&'), 4);
        $_SESSION["session"]= $userid;
        $username = $_SESSION["session"];

        $db = Util::getDb();
        $user = Controller::findOne($db->getDbserver(), 'profile_producer', 'username', $username);
        
		$wazer = Controller::findOne($db->getDbserver(), 'profile', 'phone', $id);
		$account = Controller::findOne($db->getDbserver(), 'accountstate', 'profileid', $wazer[0]);
    ?>
	<h2>The state of the account</h2>
	<menu>
		<a href=<?php echo "redirect.php?link=view/shipping/list.php&user=$username" ?>>Shippings</a> |
		<a href=<?php echo "redirect.php?link=view/payment/list.php&user=$username" ?>>Payments</a> |
		<a href=<?php echo "redirect.php?link=view/transfer/list.php&user=$username" ?>>Transfer</a> 
    </menu>
	<hr>
    <div>
        <p>The total amount in account is : $<?php echo $account[2]; ?></p>
    </div>
    
</div>