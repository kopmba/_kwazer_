<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/payment.php');


?>

<div>
    <?php 

        session_start();

         $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		$id = substr(strstr($request_uri, '&'), 4);
        $_SESSION["session"]= $userid;
        $username = $_SESSION["session"];


        $db = Util::getDb();
        $user = Controller::findOne($db->getDbserver(), 'profile_producer', 'username', $username);
        //print_r($profile);
       

        echo "List of payments";

        //echo "List of payments";

        $db = Util::getDb();
        $payments = Controller::find($db, 'payment');

        $len = count($payments);
        echo $len;
        
        if($id != '' && $id >= 0) {
            $payments = Controller::findOne($db->getDbserver(), 'payment', 'payid', $id);
            $len = 1;
        }
       // print_r($payments);

    ?>
	
	<menu>
		<a href=<?php echo "redirect.php?link=view/shipping/list.php&user=$username" ?>>Shippings</a> |
		<a href=<?php echo "redirect.php?link=view/payment/list.php&user=$username" ?>>Payments</a> |
		<a href=<?php echo "redirect.php?link=view/transfer/list.php&user=$username" ?>>Transfer</a> 
    </menu>
	<hr>
    <?php if($len >= 1): ?>
        <?php foreach ($payments as $key => $value): ?>
            
            <p>Payment done by : <?php echo $user['fullname'] ?> <a href=<?php echo "payment.php?user=$username&id=$value[0]" ?>>Details</a> | <a href=<?php echo "account.php?user=$username&id=$value[4]" ?>>Account</a> | <a href=<?php echo "commission-list.php?user=$username&id=$value[0]" ?>>Commissions</a></p>
        <?php endforeach ?>
    <?php endif ?>
    
</div>