

<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/category.php');
    
?>



<div id="container" class="container">
	 
	 <?php 
    
        session_start();
        $_SESSION["session"]='jdoe';
        $username = $_SESSION["session"];

        $db = Util::getDb();
        $user = Controller::findOne($db->getDbserver(), 'profile_producer', 'username', $username);
       // print_r($user);
        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);

        echo "List of products";

        $db = Util::getDb();
        $products = Controller::find($db, 'productpayedfromcart_with_state');
		//print_r($products);

        $len = count($products);
        echo $len;
        
        if($id && $id >= 0) {
            $product = Controller::findOne($db->getDbserver(), 'productpayedfromcart_with_state', 'ppfcid', $id);
            $len = 1;
        }
		$cuser = Controller::findOne($db->getDbserver(), 'profile_producer', 'roleid', '4');
		$refcmd = '';
		$ownerid = 0;
		$totalamount = 0;
		$uid = $user['proid'];

    ?>
	 <menu>
        <a href=<?php echo "redirect.php?link=view/comandpayed/list.php&user=$username"?>>Orders </a> |
		<a href=<?php echo "redirect.php?link=view/messages/list.php&user=$username" ?>>Messages</a> |
		<a href=<?php echo "redirect.php?link=view/payments/list.php&user=$username" ?>>Payments</a> |
		<a href=<?php echo "redirect.php?link=view/product/list.php&user=$username" ?>>Products</a> 
    </menu>
      <hr>
     
	  <?php if($user['roleid'] == 2): ?>
	    <?php if($len >= 1): ?>
			<table id="table-view" class="responsive" data-max="25">
				<thead>
					<tr>
					  <th>#</th>
					  <th>Name</th>
					  <th>Price ($)</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($products as $key => $value): ?>
						
						<?php if($value[5] == 1): ?>
							 <?php $pid=$value[2] ?>
							<?php $prod = Controller::findOne($db->getDbserver(), 'product', 'pid', $pid); ?>
							<?php $ownerid = $prod['ownerid']; ?>
							<?php $totalamount = $totalamount + $value[4]; ?>
							<tr>
							  <td><img src=<?php  echo "http://localhost/xampp/connector/view/product/uploads/$value[6]" ?> style="height:80px; width:80px;" ></td
							  <td><?php  echo $prod['pname'] ?></td>
							  <td><?php  echo $value[4] ?></td>
							  <td><a href=<?php echo "product.php?user=$username&id=$value[2]" ?>>View</a> <?php if($user['roleid'] == 1): ?>| <a href=<?php echo "edit.php?user=$username&id=$value[0]" ?>>Edit</a> | <a href=<?php echo "delete.php?user=$username&id=$value[0]" ?>>Delete</a><?php endif ?></td>
							</tr>
						<?php endif ?>
					<?php endforeach ?>
					
				</tbody>
			</table>
			
			<p>Total Amount : $<?php echo $totalamount ?></p>
			
			<br>
			<form method="post" action=<?php echo "helper/buy.php?user=$username" ?>>
				<input type="text" name="refcmd" hidden value=<?php echo $products[0][1] ?>>
				<input type="text" name="cid" hidden value=<?php echo $uid ?>>
				<input type="text" name="oid" hidden value=<?php echo $ownerid ?>>
				<input type="text" name="amount" hidden value=<?php echo $totalamount ?>>
				<input type="text" name="userid" hidden value="jdoe">
				<br>
				<input type="submit" class="asphalt" value="Buy">
			</form>
		<?php endif ?>
		
		<?php if($len < 1 ): ?>
			<p>No products in card </p>
		<?php endif ?>
	<?php endif ?>
	
	 
</div>
