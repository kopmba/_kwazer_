

<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/category.php');
    
?>


<div id="container" class="container">
	 
	 <?php 
    
        session_start();

         $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		$id = substr(strstr($request_uri, '&'), 4);
        $_SESSION["session"]= $userid;
        $username = $_SESSION["session"];


        $db = Util::getDb();
        $user = Controller::findOne($db->getDbserver(), 'profile_producer', 'username', $username);
        //print_r($profile);
       

        echo "List of products";

        $db = Util::getDb();
        $products = Controller::find($db, 'product');
	//rint_r($products);
        $len = count($products);
        echo $len;
        
        if($id && $id >= 0) {
            $products = Controller::findOne($db->getDbserver(), 'product', 'pid', $id);
            $len = 1;
        }

    ?>
	  <menu>
        <?php if($user['roleid'] == 1): ?><a href=<?php echo "redirect.php?link=view/coupon/list.php&user=$username" ?>>Coupons</a> |
		<a href=<?php echo "redirect.php?link=view/messages/list.php&user=$username" ?>>Messages</a> | <?php endif ?>
		<?php if($user['roleid'] == 2): ?>
		<a href=<?php echo "redirect.php?link=view/comandpayed/list.php&user=$username"?>>Orders </a> |
		<a href=<?php echo "redirect.php?link=view/product/cart.php&user=$username" ?>>Cart</a> |
		<a href=<?php echo "redirect.php?link=view/shipping/list.php&user=$username" ?>>Shippings</a> |
		<?php endif ?>
		<a href=<?php echo "redirect.php?link=view/payments/list.php&user=$username" ?>>Payments</a> |
		<a href=<?php echo "redirect.php?link=view/product/list.php&user=$username" ?>>Products</a> |
		<a href=<?php echo "redirect.php?link=index.php" ?>>Logout</a>
      </menu>

      <hr>
	  
	  <?php if($user['roleid'] == 1): ?>
		<a href=<?php echo "add.php?user=$username" ?>>Add |</a>
	  <?php endif ?>
	  <a href=<?php echo "redirect.php?link=view/profile/profile.php&user=$username" ?>>Settings</a>
	  <br>
      <?php if($user['roleid'] == 1): ?>
		<table id="table-view" class="responsive" data-max="25">
			<thead>
				<tr>
				  <th>Name</th>
				  <th>Brand</th>
				  <th>Category</th>
				  <th>Year</th>
				  <th>Qty</th>
				  <th>Price ($)</th>
				  <th>Actions</th>
				</tr>
			</thead>
			<tbody>
			  <?php if($len >= 1): ?>
				<?php foreach ($products as $key => $value): ?>
					<?php if($id == ''): ?>
						<?php $category = Controller::findOne($db->getDbserver(), 'category', 'caid', $value[3]); ?>
						<tr>
						  <td><?php  echo $value[2] ?></td>
						  <td><?php  echo $value[1] ?></td>
						  <td><?php  echo $category[1] ?></td>
						  <td><?php  echo $value[6] ?></td>
						  <td><?php  echo $value[7] ?></td>
						  <td><?php  echo $value[5] ?></td>
						  <td><a href=<?php echo "product.php?user=$username&id=$value[0]" ?>>View</a> <?php if($user['roleid'] == 1): ?>| <a href=<?php echo "edit.php?user=$username&id=$value[0]" ?>>Edit</a> | <a href=<?php echo "delete.php?user=$username&id=$value[0]" ?>>Delete</a><?php endif ?></td>
						</tr>
					<?php endif ?>
					<?php if($id != ''): ?>
						<?php $category = Controller::findOne($db->getDbserver(), 'category', 'caid', $value[3]); ?>
						<tr>
						  <td><?php  echo $value[2] ?></td>
						  <td><?php  echo $value[1] ?></td>
						  <td><?php  echo $category[1] ?></td>
						  <td><?php  echo $value[6] ?></td>
						  <td><?php  echo $value[7] ?></td>
						  <td><?php  echo $value[5] ?></td>
						  <td><a href=<?php echo "product.php?user=$username&id=$value[0]" ?>>View</a> <?php if($user['roleid'] == 1): ?>| <a href=<?php echo "edit.php?user=$username&id=$value[0]" ?>>Edit</a> | <a href=<?php echo "delete.php?user=$username&id=$value[0]" ?>>Delete</a><?php endif ?></td>
						</tr>
					<?php endif ?>
				<?php endforeach ?>
			  <?php endif ?>
				
			</tbody>
		</table>
	  <?php endif ?>
	  
	  <?php if($user['roleid'] != 1): ?>
		<?php foreach ($products as $key => $value): ?>
			<div class="one fourth three-up-small-tablet two-up-mobile padded bounceInDown animated">
			  <div class="box">
				<a href=<?php echo "consumer-product.php?user=$username&id=$value[0]" ?>>
					<h4 data-compression="7" data-max="20" class="responsive align-center zero"><?php  echo $value[2] ?></h4><img style="height:80px; width:80px;" src=<?php echo "http://localhost/xampp/connector/view/product/uploads/$value[8]" ?>>
					<p class="truncate"><?php  echo $value[4] ?></p>
					
				</a>
			  </div>
			</div>
		<?php endforeach ?>
	  <?php endif ?>
</div>