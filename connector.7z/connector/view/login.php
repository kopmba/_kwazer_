<!DOCTYPE html>
<html>
      <head>
      </head>

      <body class="text-center">
		
        <form action="dashboard/dashboard.php" method="POST">
         
		<br><br>
		 <h1 style="color:blue;">Shop connector</h1>
         <h5  style="color:green;" class="h3 mb-3 font-weight-normal">Se connecter</h5>
         <label for="inputUsername" class="sr-only">Username</label>
         <input type="text" id="inputUsername" name="username" class="form-control" placeholder="Username" required autofocus>
         <br>
         <label for="inputPassword" class="sr-only">Password</label>
         <input type="password" id="inputPassword" name="password" class="form-control" placeholder="Password" required>
         <div class="checkbox mb-3">
           <a href="forget_password.php" class="forgot-pass">Forgot Password?</a>
         </div>
         <button style="color:green" class="btn btn-lg btn-light btn-block" type="submit">Sign in</button>
         <p class="mt-5 mb-3 text-muted">&copy; Mardets</p>
        </form>
      </body>
 </html>