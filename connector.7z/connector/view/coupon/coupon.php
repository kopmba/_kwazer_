<?php 

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/category.php');
    
?>

<div>
    <?php 
        session_start();
        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6, 10);
        $_SESSION["session"]= $userid;
        $username = $_SESSION["session"];

        $db = Util::getDb();
        $user = Controller::findOne($db->getDbserver(), 'profile_producer', 'username', $username);
		
		$coupo = Controller::findOne($db->getDbserver(), 'coupon', 'coid',$id);
		$producer = Controller::findOne($db->getDbserver(), 'profile', 'proid', $coupo[1]);
		$conector = Controller::findOne($db->getDbserver(), 'profile', 'proid', $coupo[2]); 
		$cmdp = Controller::findOne($db->getDbserver(), 'commandpayed', 'cpid', $coupo[3]); 
	//rint_r($coupo);
    ?>
	<menu>
        <a href=<?php echo "redirect.php?link=view/coupon/list.php&user=$username" ?>>Coupons</a> |
		<a href=<?php echo "redirect.php?link=view/messages/list.php&user=$username" ?>>Messages</a> |
		<a href=<?php echo "redirect.php?link=view/payments/list.php&user=$username" ?>>Payments</a> |
		<a href=<?php echo "redirect.php?link=view/product/list.php&user=$username" ?>>Products</a> |
				<a href=<?php echo "redirect.php?link=index.php" ?>>Logout</a>

      </menu>

   <div>
        <p><h3>The coupon ref : </h3> <?php echo $cmdp['refcmd'] ?> with amount of <?php echo $cmdp['totalamount'] ?>
    </div>
    
</div>