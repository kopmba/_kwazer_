

<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/category.php');
    
?>




<div id="container" class="container">
	 
	 <?php 
    
        session_start();

         $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		$id = substr(strstr($request_uri, '&'), 4);
        $_SESSION["session"]= $userid;
        $username = $_SESSION["session"];

        $db = Util::getDb();
        $user = Controller::findOne($db->getDbserver(), 'profile_producer', 'username', $username);
        //print_r($profile);
       

        echo "List of coupons";

        $db = Util::getDb();
        $coupons = Controller::find($db, 'coupon');

        $len = count($coupons);
        echo $len;
        
        if($id && $id >= 0) {
            $coupon = Controller::findOne($db->getDbserver(), 'coupon', 'coid', $id);
            $len = 1;
        }

    ?>
	
	 <menu>
        <a href=<?php echo "redirect.php?link=view/coupon/list.php&user=$username" ?>>Coupons</a> |
		<a href=<?php echo "redirect.php?link=view/messages/list.php&user=$username" ?>>Messages</a> |
		<a href=<?php echo "redirect.php?link=view/payments/list.php&user=$username" ?>>Payments</a> |
		<a href=<?php echo "redirect.php?link=view/product/list.php&user=$username" ?>>Products</a> |
				<a href=<?php echo "redirect.php?link=index.php" ?>>Logout</a>

      </menu>

      <hr>
      
     <?php if($user['roleid'] == 1): ?>
				<table id="table-view" class="responsive" data-max="25">
					<thead>
						<tr>
						  <th>Refcmd</th>
						  <th>Producer</th>
						  <th>Connector</th>
						  <th>Amount ($)</th>
						  <th>Actions</th>
						</tr>
					</thead>
					<tbody>
					  <?php if($len >=1): ?>
						<?php foreach ($coupons as $key => $value): ?>
							<?php if($id == ''): ?>
								<?php $producer = Controller::findOne($db->getDbserver(), 'profile', 'proid', $value[1]); ?>
								<?php $conector = Controller::findOne($db->getDbserver(), 'profile', 'proid', $value[2]); ?>
								<?php $cmdp = Controller::findOne($db->getDbserver(), 'commandpayed', 'cpid', $value[3]); ?>
								
								<tr>
								  <td><?php  echo $cmdp[1] ?></td>
								  <td><?php  echo $producer[3] ?></td>
								  <td><?php  echo $conector[3] ?></td>
								  <td><?php  echo $cmdp[5] ?></td>
								  <td><a href=<?php echo "coupon.php?user=$username&id=$value[0]" ?>>View</a> <?php if($user['roleid'] == 1): ?>| <a href=<?php echo "edit.php?user=$username&id=$value[0]" ?>>Edit</a> | <a href=<?php echo "delete.php?user=$username&id=$value[0]" ?>>Delete</a><?php endif ?></td>
								</tr>
							<?php endif ?>
						<?php endforeach ?>
					  <?php endif ?>
						
					</tbody>
				</table>
			<?php endif ?>

</div>