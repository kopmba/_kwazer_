<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/payment.php');


?>

<div>
    <?php 

        session_start();

         $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		$id = substr(strstr($request_uri, '&'), 4);
        $_SESSION["session"]= $userid;
        $username = $_SESSION["session"];


        $db = Util::getDb();
        $user = Controller::findOne($db->getDbserver(), 'profile_producer', 'username', $username);
        //print_r($profile);
       

        echo "List of transfers";

        //echo "List of payments";

        $db = Util::getDb();
        $transfers = Controller::find($db, 'transfer');

        $len = count($transfers);
        echo $len;
        
        
       // print_r($payments);

    ?>
	
	<menu>
		<a href=<?php echo "redirect.php?link=view/shipping/list.php&user=$username" ?>>Shippings</a> |
		<a href=<?php echo "redirect.php?link=view/payment/list.php&user=$username" ?>>Payments</a> |
		<a href=<?php echo "redirect.php?link=view/transfer/list.php&user=$username" ?>>Transfer</a> 
    </menu>

    <?php if($len >= 1): ?>
        <?php foreach ($transfers as $key => $value): ?>
            <?php $payment = Controller::findOne($db->getDbserver(), 'payment', 'payid', $value[1]); ?>
			<?php $order = Controller::findOne($db->getDbserver(), 'commandpayed', 'cpid', $payment[1]); ?>
			<?php $producer = Controller::findOne($db->getDbserver(), 'profile', 'proid', $order[3]); ?>
			<?php $shipping = Controller::findOne($db->getDbserver(), 'shipping', 'cmdpayedid', $order[0]); ?>
			<?php $shipper = Controller::findOne($db->getDbserver(), 'profile', 'proid', $shipping[2]); ?>
            <p>transfer done by : <?php echo $user['fullname'] ?> 
				to <?php echo $producer['fullname'] ?> and <?php echo $shipper['fullname'] ?> <br>
        <?php endforeach ?>
    <?php endif ?>
    
</div>