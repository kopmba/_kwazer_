<?php 
 $header = 
 '<header class="header" style="margin-left: 205px">
        <nav class="navbar">
          <!-- Search Box-->
          <div class="search-box">
            <button class="dismiss"><i class="icon-close"></i></button>
            <form id="searchForm" action="#" role="search">
              <input type="search" placeholder="What are you looking for..." class="form-control">
            </form>
          </div>
          <div class="container-fluid">
            <div class="navbar-holder d-flex align-items-center justify-content-between">
              <!-- Navbar Header-->
              <div class="navbar-header">
                <!-- Navbar Brand -->
                <a href="index.html" class="navbar-brand d-none d-sm-inline-block">
                  <div class="brand-text d-none d-sm-inline-block d-lg-none">
                  	<strong>BD</strong>
                  </div>
              	</a>
                <!-- Toggle Button-->
              </div>
                

             <!--  -->

         

        </nav>
               
                
            </div>
          </div>
        </nav>
      </header>';
	
	echo $header;
?>