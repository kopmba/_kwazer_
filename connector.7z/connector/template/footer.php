<?php 

$footer = 
  '<footer class="gap-top bounceInUp animated">
      <div class="box square">
        <div class="container padded">
          <div class="row">
            <div class="one half padded">
              <p>Wazac is a <b>M@rdets project</b>. <a href="mard@mardets.com">Envoyer nous un mail</a> si vous avez une question.</p>
            </div>
            <div class="one half padded">
              <p class="large padded align-right align-center-small-tablet"><a href="http://mardets.com/products/wazac" target="_blank" title="@wazac" style="text-decoration:none;" class="large inline gapped"></a></p>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <script type="text/javascript" src="v1/groundwork-master/js/groundwork.all.js"></script>';
	
	echo $footer;
	
?>