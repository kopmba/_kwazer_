<?php
 $head = 
  '<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
    <title>Waza commerce</title>
    <script src="http://localhost/v1/groundwork-master/js/libs/modernizr-2.6.2.min.js"></script>
    <script type="text/javascript" src="http://localhost/v1/groundwork-master/js/libs/jquery-1.10.2.min.js"></script>
    <link type="text/css" rel="stylesheet" href="http://localhost/v1/groundwork-master/css/groundwork.css">
    <link type="text/css" rel="stylesheet" href="css/wazac.css">
    <script type="text/javascript" src="http://localhost/v1/groundwork-master/js/demo/jquery.snippet.min.js"></script>
    <link type="text/css" rel="stylesheet" href="http://localhost/v1/groundwork-master/css/demo/jquery.snippet.css">
    <script type="text/javascript" src="js/wazac.js"></script>
  </head>';
   
 echo $head;
 
?>