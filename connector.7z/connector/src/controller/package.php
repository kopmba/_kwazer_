<?php

     class PackageController extends Controller {

            public static function uploadPackage() {
                    
            }

			public static function createPackage() {
				//get db server
				$db = Util::getDb();

				//remote together database server
				$tdb = Util::getTDb();

				//$username = $_POST['userid'];
				//$profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

				$pname = $_POST['pname'];
				$description = $_POST['description'];
				
				$date_created = new DateTime();
				
				$package = array();
				$package['pname'] = $pname;
				$package['description'] = $description;
				$package['price'] = $_POST['price'];
				$package['products'] = substr(strstr($_POST['products'], '&'), 1);
				$package['imgs'] = '';
				$package['subscribers'] = '';
				$package['created'] = $date_created->format('Y-m-d H:i:s');
				$package['edited'] = $date_created->format('Y-m-d H:i:s');

				Controller::save($db, 'package', 'paid', $package);

			}

			public static function updatePackage() {
				//get db server
				$db = Util::getDb();

				//remote together database server
				$tdb = Util::getTDb();

				//$username = $_POST['userid'];
				//$profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

				$paid = $_POST['paid'];
				$package = Controller::findOne($db->getDbserver(), 'package', 'paid', $paid);

				$pname = $_POST['pname'];
				$description = $_POST['description'];
				
				$date_created = new DateTime();
				
				$updated_package = $package;
				$updated_package['pname'] = $pname;
				$updated_package['description'] = $description;
				$updated_package['price'] = $_POST['price'];
				$updated_package['products'] = substr(strstr($_POST['products'], '&'), 1);
				$updated_package['edited'] = $date_created->format('Y-m-d H:i:s');
					 
				Controller::update($db, 'package', 'paid', $paid, $updated_package);
				
            }
            
            public static function removePackage() {
				//get db server
				$db = Util::getDb();

				//remote together database server
				$tdb = Util::getTDb();

				//$username = $_POST['userid'];

				$paid = $_POST['paid'];
				$package = Controller::findOne($db->getDbserver(), 'package', 'paid', $paid);
					 
				Controller::delete($db->getDbserver(), 'package', 'paid', $paid);
			}

			public static function product_list() {
				//get db server
				$db = Util::getDb();

				$paid = $_POST['paid'];
				$package = Controller::findOne($db->getDbserver(), 'package', 'paid', $paid);

				$products = $package['products'];

				return $products;
			}

			public static function subscriber_list() {
				//get db server
				$db = Util::getDb();

				$paid = $_POST['paid'];
				$package = Controller::findOne($db->getDbserver(), 'package', 'paid', $paid);

				$subscribers = $package['subscribers'];

				return $subscribers;
			}

     }

?>
