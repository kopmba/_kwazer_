<?php

     class PaymentController extends Controller {

			public static function createPayment() {
				//get db server
				$db = Util::getDb();

				//remote together database server
				$tdb = Util::getTDb();

				//$username = $_POST['userid'];
				//$profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

				$date_created = new DateTime();
				
				$payment = array();
				$payment['opname'] = $_POST['opname'];
				$payment['senderid'] = $_POST['senderid'];
				$payment['receiverid'] = $_POST['receiverid'];
				$payment['amount'] = $_POST['amount'];
				$payment['packageid'] = $_POST['packageid'];
				$payment['productid'] = $_POST['productid'];
				$payment['created'] = $date_created->format('Y-m-d H:i:s');
				$payment['edited'] = $date_created->format('Y-m-d H:i:s');

				Controller::save($db, 'payment', 'payid', $payment);
			}

			public static function createPackagePayment() {
				//get db server
				$db = Util::getDb();

				//remote together database server
				$tdb = Util::getTDb();

				//$username = $_POST['userid'];
				//$profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

				$date_created = new DateTime();
				
				$payment = array();
				$payment['opname'] = '';
				$payment['senderid'] = $_POST['senderid'];
				$payment['receiverid'] = '';
				$payment['amount'] = $_POST['amount'];
				$payment['packageid'] = $_POST['packageid'];
				$payment['productid'] = '';
				$payment['created'] = $date_created->format('Y-m-d H:i:s');
				$payment['edited'] = $date_created->format('Y-m-d H:i:s');

				Controller::save($db, 'payment', 'payid', $payment);
			}

			public static function createProductPayment() {
				//get db server
				$db = Util::getDb();

				//remote together database server
				$tdb = Util::getTDb();

				//$username = $_POST['userid'];
				//$profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

				$date_created = new DateTime();
				
				$payment = array();
				$payment['opname'] = '';
				$payment['senderid'] = $_POST['senderid'];
				$payment['receiverid'] = '';
				$payment['amount'] = $_POST['amount'];
				$payment['productid'] = $_POST['productid'];
				$payment['packageid'] = '';
				$payment['created'] = $date_created->format('Y-m-d H:i:s');
				$payment['edited'] = $date_created->format('Y-m-d H:i:s');

				Controller::save($db, 'payment', 'payid', $payment);
			}

     }

?>
